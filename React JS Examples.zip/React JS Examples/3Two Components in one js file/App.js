import React, { Component } from 'react';
import './App.css';

class Button extends Component{
	render() {
		return(
			<button onClick={this.props.onClickFunction}>
				+1
			</button>
		);
	}
}

const Result = (props) => {
	return(
		<div>{props.counter}</div>
	);
};

class App extends Component {
	state = {counter: 0};
	
	handleClick = () => {
		this.setState({
			counter: this.state.counter +1
		})
	}
	
	render() {
		return (
			<div>
				<Button onClickFunction={this.handleClick} />
				<Result counter={this.state.counter} />
			</div>
		);
	}
}

export default App;
