import React, { Component } from 'react';
import data from './data.json';
 
class App extends Component {
  render() {
    return (
        <ul>
        {
          data.map(function(book){
            return <li>{book.id} - {book.title}</li>;
          })
        }
        </ul>
    );
  }
}
 
export default App;