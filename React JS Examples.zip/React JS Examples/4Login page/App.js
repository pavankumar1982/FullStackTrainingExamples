import React, { Component } from 'react';
import './App.css';



class App extends Component {
   constructor(props) {
      super(props);
      
      this.state = {
         user: 'Username',
		 pass: 'Password',
		 data: 'Enter cg and cg and press <Login> button'
      }
      this.updateState = this.updateState.bind(this);
   };
   checkLogin(e) {
      this.setState({
		  if(user == 'cg' && pass == 'cg')
			  data: 'Login Success'
		  else
			  data: 'Login Fail'
	  });
   }
   render() {
      return (
         <div>
            Username: <input type = "text" value = {this.state.user} onChange = {this.updateState} /> <br/><br/>
			Password: <input type = "password" value ={this.state.pass} />
			<button onClick={this.checkLogin}>Login</button>
            <h4>{this.state.data}</h4>
         </div>
      );
   }
}

export default App;
